﻿using System;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace DaftarMantanApp
{
    public class MainMenu : Form
    {
        private Button btnInput;
        private Button btnList;

        public MainMenu()
        {
            this.Text = "Daftar Mantan - Menu Utama";
            this.Size = new Size(500, 350);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.MistyRose; // Latar nuansa patah hati

            Label lblTitle = new Label()
            {
                Text = "Aplikasi Daftar Mantan 💔",
                Font = new Font("Segoe UI", 20, FontStyle.Bold),
                AutoSize = true,
                ForeColor = Color.Maroon
            };
            // Tengah horizontal
            lblTitle.Location = new Point((this.ClientSize.Width - lblTitle.Width) / 2, 30);
            lblTitle.Anchor = AnchorStyles.Top | AnchorStyles.Left;

            btnInput = new Button()
            {
                Text = "➕ Tambah Mantan Baru",
                Width = 250,
                Height = 50,
                Font = new Font("Segoe UI", 12, FontStyle.Regular),
                BackColor = Color.LightCoral,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnInput.Location = new Point((this.ClientSize.Width - btnInput.Width) / 2, 100);
            btnInput.Click += BtnInput_Click;

            btnList = new Button()
            {
                Text = "📜 Lihat Daftar Mantan",
                Width = 250,
                Height = 50,
                Font = new Font("Segoe UI", 12, FontStyle.Regular),
                BackColor = Color.IndianRed,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnList.Location = new Point((this.ClientSize.Width - btnList.Width) / 2, 180);
            btnList.Click += BtnList_Click;

            this.Controls.Add(lblTitle);
            this.Controls.Add(btnInput);
            this.Controls.Add(btnList);

            // Supaya posisi tetap center saat resize
            this.Resize += (s, e) =>
            {
                lblTitle.Left = (this.ClientSize.Width - lblTitle.Width) / 2;
                btnInput.Left = (this.ClientSize.Width - btnInput.Width) / 2;
                btnList.Left = (this.ClientSize.Width - btnList.Width) / 2;
            };
        }

        private void BtnInput_Click(object sender, EventArgs e)
        {
            FormMain inputForm = new FormMain();
            inputForm.ShowDialog();
        }

        private void BtnList_Click(object sender, EventArgs e)
        {
            FormList listForm = new FormList();
            listForm.ShowDialog();
        }
    }
}
