﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace DaftarMantanApp
{
    public class FormMain : Form
    {
        private TextBox txtNama;
        private DateTimePicker dtpTanggalLahir;
        private TextBox txtCiriCiri;
        private PictureBox pictureBoxFoto;
        private Button btnSubmit;
        private Button btnLihatDaftar;
        private string fotoPath = "";

        public FormMain()
        {
            this.Text = "💔 Tambah Mantan";
            this.Size = new Size(600, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Color.MistyRose;

            Font labelFont = new Font("Segoe UI", 12, FontStyle.Bold);
            Font inputFont = new Font("Segoe UI", 11);

            int labelLeft = 50;
            int inputLeft = 50;
            int formWidth = this.ClientSize.Width;

            Label lblTitle = new Label()
            {
                Text = "📝 Form Tambah Mantan",
                Font = new Font("Segoe UI", 20, FontStyle.Bold),
                ForeColor = Color.Maroon,
                AutoSize = true,
                Top = 20,
                Left = (formWidth - 300) / 2
            };
            this.Controls.Add(lblTitle);

            Label lblNama = new Label() { Text = "Nama:", Top = 80, Left = labelLeft, Width = 200, Font = labelFont };
            txtNama = new TextBox() { Top = 110, Left = inputLeft, Width = 480, Font = inputFont };

            Label lblTanggal = new Label() { Text = "Tanggal Lahir:", Top = 150, Left = labelLeft, Width = 200, Font = labelFont };
            dtpTanggalLahir = new DateTimePicker() { Top = 180, Left = inputLeft, Width = 480, Font = inputFont };

            Label lblCiriCiri = new Label() { Text = "Ciri-ciri:", Top = 220, Left = labelLeft, Width = 200, Font = labelFont };
            txtCiriCiri = new TextBox() { Top = 250, Left = inputLeft, Width = 480, Height = 80, Multiline = true, Font = inputFont };

            Label lblFoto = new Label() { Text = "Foto:", Top = 340, Left = labelLeft, Width = 200, Font = labelFont };
            pictureBoxFoto = new PictureBox()
            {
                Top = 370,
                Left = inputLeft,
                Width = 150,
                Height = 150,
                BorderStyle = BorderStyle.FixedSingle,
                SizeMode = PictureBoxSizeMode.Zoom
            };

            Button btnBrowseFoto = new Button()
            {
                Text = "📷 Pilih Foto",
                Top = 530,
                Left = inputLeft + 160,
                Width = 120,
                Height = 40,
                Font = new Font("Segoe UI", 10),
                BackColor = Color.LightSalmon,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnBrowseFoto.Click += BtnBrowseFoto_Click;

            btnSubmit = new Button()
            {
                Text = "💾 Simpan",
                Top = 590,
                Left = 100,
                Width = 150,
                Height = 45,
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                BackColor = Color.IndianRed,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnSubmit.Click += BtnSubmit_Click;

            btnLihatDaftar = new Button()
            {
                Text = "📜 Lihat Daftar",
                Top = 590,
                Left = 330,
                Width = 150,
                Height = 45,
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                BackColor = Color.Maroon,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnLihatDaftar.Click += BtnLihatDaftar_Click;

            this.Controls.Add(lblNama);
            this.Controls.Add(txtNama);
            this.Controls.Add(lblTanggal);
            this.Controls.Add(dtpTanggalLahir);
            this.Controls.Add(lblCiriCiri);
            this.Controls.Add(txtCiriCiri);
            this.Controls.Add(lblFoto);
            this.Controls.Add(pictureBoxFoto);
            this.Controls.Add(btnBrowseFoto);
            this.Controls.Add(btnSubmit);
            this.Controls.Add(btnLihatDaftar);
        }

        private void BtnBrowseFoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                FileInfo fileInfo = new FileInfo(ofd.FileName);
                if (fileInfo.Length > 10 * 1024 * 1024)
                {
                    MessageBox.Show("Ukuran file terlalu besar. Maksimum 10 MB.");
                    return;
                }

                string imageFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Images");
                if (!Directory.Exists(imageFolder)) Directory.CreateDirectory(imageFolder);

                string destFileName = Path.Combine(imageFolder, Path.GetFileName(ofd.FileName));
                File.Copy(ofd.FileName, destFileName, true);

                fotoPath = destFileName;
                pictureBoxFoto.Image = Image.FromFile(fotoPath);
            }
        }

        private void BtnSubmit_Click(object sender, EventArgs e)
        {
            string nama = txtNama.Text.Trim();
            DateTime tanggal = dtpTanggalLahir.Value;
            string ciri = txtCiriCiri.Text.Trim();

            if (string.IsNullOrEmpty(nama) || string.IsNullOrEmpty(ciri) || string.IsNullOrEmpty(fotoPath))
            {
                MessageBox.Show("Semua field harus diisi termasuk foto.");
                return;
            }

            try
            {
                Database db = new Database();
                bool result = db.InsertMantan(nama, tanggal, ciri, fotoPath);

                if (result)
                {
                    MessageBox.Show("Data mantan berhasil disimpan.");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Gagal menyimpan data.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Terjadi kesalahan: " + ex.Message);
            }
        }

        private void BtnLihatDaftar_Click(object sender, EventArgs e)
        {
            FormList listForm = new FormList();
            listForm.Show();
        }
    }
}
