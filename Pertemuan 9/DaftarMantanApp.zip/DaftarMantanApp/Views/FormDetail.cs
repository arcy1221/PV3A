﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace DaftarMantanApp
{
    public class FormDetail : Form
    {
        private int mantanId;

        private Label lblJudul;
        private Label lblNama;
        private Label lblTanggal;
        private Label lblCiri;
        private PictureBox pictureBoxFoto;

        public FormDetail(int id)
        {
            this.mantanId = id;
            this.Text = "Detail Data Mantan 💔";
            this.Size = new Size(500, 650);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(255, 240, 245); // Pink pucat
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            Font fontTitle = new Font("Segoe UI", 18, FontStyle.Bold);
            Font fontLabel = new Font("Segoe UI", 12, FontStyle.Regular);

            lblJudul = new Label()
            {
                Text = "💔 Detail Data Mantan",
                Font = fontTitle,
                AutoSize = true,
                ForeColor = Color.Maroon,
                Top = 20,
                Left = 50
            };

            lblNama = new Label()
            {
                Text = "Nama: ",
                Font = fontLabel,
                AutoSize = true,
                Top = 80,
                Left = 40,
                ForeColor = Color.Black
            };

            lblTanggal = new Label()
            {
                Text = "Tanggal Lahir: ",
                Font = fontLabel,
                AutoSize = true,
                Top = 120,
                Left = 40,
                ForeColor = Color.Black
            };

            lblCiri = new Label()
            {
                Text = "Ciri-ciri: ",
                Font = fontLabel,
                AutoSize = true,
                Top = 160,
                Left = 40,
                ForeColor = Color.Black
            };

            pictureBoxFoto = new PictureBox()
            {
                Top = 210,
                Left = 100,
                Width = 280,
                Height = 350,
                BorderStyle = BorderStyle.Fixed3D,
                SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Color.White
            };

            this.Controls.Add(lblJudul);
            this.Controls.Add(lblNama);
            this.Controls.Add(lblTanggal);
            this.Controls.Add(lblCiri);
            this.Controls.Add(pictureBoxFoto);

            LoadData();
        }

        private void LoadData()
        {
            Database db = new Database();
            using (MySqlConnection conn = db.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM mantan WHERE id = @id";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@id", mantanId);

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string nama = reader["nama"].ToString();
                            string tanggal = Convert.ToDateTime(reader["tanggal_lahir"]).ToString("dd MMMM yyyy");
                            string ciri = reader["ciri_ciri"].ToString();
                            string fotoPath = reader["foto_path"].ToString();

                            lblNama.Text = "Nama: " + nama;
                            lblTanggal.Text = "Tanggal Lahir: " + tanggal;
                            lblCiri.Text = "Ciri-ciri: " + ciri;

                            if (!string.IsNullOrEmpty(fotoPath) && File.Exists(fotoPath))
                            {
                                using (Image original = Image.FromFile(fotoPath))
                                {
                                    Image displayImage = (Image)original.Clone();

                                    if (displayImage.Width > displayImage.Height)
                                    {
                                        displayImage.RotateFlip(RotateFlipType.Rotate90FlipNone);
                                    }

                                    pictureBoxFoto.Image = displayImage;
                                }
                            }
                            else
                            {
                                pictureBoxFoto.Image = null;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Gagal memuat data: " + ex.Message);
                }
            }
        }
    }
}
