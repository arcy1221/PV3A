﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace DaftarMantanApp
{
    public class FormUpdate : Form
    {
        private int mantanId;

        private TextBox txtNama, txtCiri;
        private DateTimePicker dtpTanggal;
        private PictureBox pictureBoxFoto;
        private Button btnBrowse, btnUpdate;

        private string fotoPath = "";

        public FormUpdate(int id)
        {
            mantanId = id;
            this.Text = "💔 Update Data Mantan";
            this.Size = new Size(500, 800); // Diperbesar agar cukup
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(255, 240, 245); // Pink muda
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.AutoScroll = true; // Aktifkan scroll jika konten terlalu panjang

            Font fontLabel = new Font("Segoe UI", 12, FontStyle.Regular);
            Font fontTitle = new Font("Segoe UI", 16, FontStyle.Bold);

            Label lblHeader = new Label()
            {
                Text = "💔 Update Data Mantan",
                Font = fontTitle,
                AutoSize = true,
                Top = 20,
                Left = 100,
                ForeColor = Color.Maroon
            };

            Label lblNama = new Label() { Text = "Nama:", Font = fontLabel, Top = 80, Left = 40 };
            txtNama = new TextBox() { Top = 110, Left = 40, Width = 400 };

            Label lblTanggal = new Label() { Text = "Tanggal Lahir:", Font = fontLabel, Top = 150, Left = 40 };
            dtpTanggal = new DateTimePicker() { Top = 180, Left = 40, Width = 200 };

            Label lblCiri = new Label() { Text = "Ciri-ciri:", Font = fontLabel, Top = 220, Left = 40 };
            txtCiri = new TextBox() { Top = 250, Left = 40, Width = 400, Height = 80, Multiline = true };

            pictureBoxFoto = new PictureBox()
            {
                Top = 350,
                Left = 100,
                Width = 280,
                Height = 280,
                BorderStyle = BorderStyle.Fixed3D,
                SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Color.White
            };

            btnBrowse = new Button()
            {
                Text = "📁 Browse Foto",
                Top = pictureBoxFoto.Bottom + 20, // Dinamis setelah gambar
                Left = 100,
                Width = 120,
                BackColor = Color.LightPink
            };
            btnBrowse.Click += BtnBrowse_Click;

            btnUpdate = new Button()
            {
                Text = "💾 Update",
                Top = pictureBoxFoto.Bottom + 20,
                Left = 250,
                Width = 120,
                BackColor = Color.Maroon,
                ForeColor = Color.White
            };
            btnUpdate.Click += BtnUpdate_Click;

            this.Controls.AddRange(new Control[] {
                lblHeader,
                lblNama, txtNama,
                lblTanggal, dtpTanggal,
                lblCiri, txtCiri,
                pictureBoxFoto, btnBrowse, btnUpdate
            });

            LoadData();
        }

        private void LoadData()
        {
            Database db = new Database();
            using (MySqlConnection conn = db.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM mantan WHERE id = @id";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@id", mantanId);

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            txtNama.Text = reader["nama"].ToString();
                            dtpTanggal.Value = Convert.ToDateTime(reader["tanggal_lahir"]);
                            txtCiri.Text = reader["ciri_ciri"].ToString();
                            fotoPath = reader["foto_path"].ToString();

                            if (File.Exists(fotoPath))
                            {
                                pictureBoxFoto.Image = Image.FromFile(fotoPath);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Gagal load data: " + ex.Message);
                }
            }
        }

        private void BtnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                FileInfo file = new FileInfo(ofd.FileName);
                if (file.Length > 10 * 1024 * 1024)
                {
                    MessageBox.Show("Ukuran foto maksimal 10 MB.");
                    return;
                }

                fotoPath = ofd.FileName;
                pictureBoxFoto.Image = Image.FromFile(fotoPath);
            }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            string nama = txtNama.Text.Trim();
            DateTime tanggal = dtpTanggal.Value;
            string ciri = txtCiri.Text.Trim();

            if (string.IsNullOrEmpty(nama) || string.IsNullOrEmpty(ciri))
            {
                MessageBox.Show("Nama dan Ciri-ciri tidak boleh kosong.");
                return;
            }

            Database db = new Database();
            using (MySqlConnection conn = db.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = "UPDATE mantan SET nama=@nama, tanggal_lahir=@tgl, ciri_ciri=@ciri, foto_path=@foto WHERE id=@id";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@nama", nama);
                    cmd.Parameters.AddWithValue("@tgl", tanggal);
                    cmd.Parameters.AddWithValue("@ciri", ciri);
                    cmd.Parameters.AddWithValue("@foto", fotoPath);
                    cmd.Parameters.AddWithValue("@id", mantanId);

                    int result = cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        MessageBox.Show("Data berhasil diupdate.");
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Gagal mengupdate data.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error update: " + ex.Message);
                }
            }
        }
    }
}
