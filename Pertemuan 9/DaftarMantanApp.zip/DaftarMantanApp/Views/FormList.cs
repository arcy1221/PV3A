﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using DaftarMantanApp.Models;
using DaftarMantanApp.Controllers;
using System.Linq;

namespace DaftarMantanApp.Views
{
    public class FormList : Form
    {
        private DataGridView dataGridView;

        public FormList()
        {
            this.Text = "📜 Daftar Mantan";
            this.Size = new Size(800, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.LavenderBlush;

            Font fontHeader = new Font("Segoe UI", 16, FontStyle.Bold);
            Font fontButton = new Font("Segoe UI", 10, FontStyle.Bold);

            Label lblTitle = new Label()
            {
                Text = "📋 Daftar Mantan Tersimpan",
                Font = fontHeader,
                ForeColor = Color.Maroon,
                AutoSize = true,
                Top = 20,
                Left = 20
            };
            this.Controls.Add(lblTitle);

            Button btnCreate = new Button()
            {
                Text = "➕ Tambah Baru",
                Top = 65,
                Left = 20,
                Width = 150,
                Height = 35,
                Font = fontButton,
                BackColor = Color.IndianRed,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnCreate.Click += BtnCreate_Click;

            dataGridView = new DataGridView()
            {
                Top = 110,
                Left = 20,
                Width = 740,
                Height = 420,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                AllowUserToAddRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                BackgroundColor = Color.White,
                Font = new Font("Segoe UI", 10),
                GridColor = Color.LightGray
            };
            dataGridView.CellClick += DataGridView_CellClick;

            this.Controls.Add(btnCreate);
            this.Controls.Add(dataGridView);

            LoadData();
        }

        private void BtnCreate_Click(object sender, EventArgs e)
        {
            FormMain formMain = new FormMain();
            formMain.FormClosed += (s, args) => LoadData(); // reload data setelah tambah
            formMain.Show();
        }

       private void LoadData()
{
    Database db = new Database();
    List<Mantan> list = db.GetAllMantan();

    DataTable dt = new DataTable();
    dt.Columns.Add("id", typeof(int));
    dt.Columns.Add("nama", typeof(string));
    dt.Columns.Add("tanggal_lahir", typeof(string));
    dt.Columns.Add("ciri_ciri", typeof(string));
    dt.Columns.Add("alamat", typeof(string));
    dt.Columns.Add("foto", typeof(string));

    foreach (var m in list)
    {
        dt.Rows.Add(m.Id, m.Nama, m.TanggalLahir.ToShortDateString(), m.CiriCiri, m.Alamat, m.Foto);
    }

    dataGridView.Columns.Clear();
    dataGridView.DataSource = dt;

    AddButtonColumn("Read");
    AddButtonColumn("Update");
    AddButtonColumn("Delete");
}



        private void AddButtonColumn(string name)
        {
            if (!dataGridView.Columns.Contains(name))
            {
                DataGridViewButtonColumn btnColumn = new DataGridViewButtonColumn();
                btnColumn.Name = name;
                btnColumn.HeaderText = name;
                btnColumn.Text = name switch
                {
                    "Read" => "👁️ Lihat",
                    "Update" => "✏️ Edit",
                    "Delete" => "🗑️ Hapus",
                    _ => name
                };
                btnColumn.UseColumnTextForButtonValue = true;
                dataGridView.Columns.Add(btnColumn);
            }
        }

        private void DataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0)
                return;

            string action = dataGridView.Columns[e.ColumnIndex].Name;

            if (!int.TryParse(dataGridView.Rows[e.RowIndex].Cells["id"].Value?.ToString(), out int id))
            {
                MessageBox.Show("ID tidak valid.");
                return;
            }

            if (action == "Read")
            {
                FormDetail detail = new FormDetail(id);
                detail.Show();
            }
            else if (action == "Update")
            {
                FormUpdate update = new FormUpdate(id);
                update.FormClosed += (s, args) => LoadData();
                update.Show();
            }
            else if (action == "Delete")
            {
                var confirm = MessageBox.Show("Yakin ingin menghapus data ini?", "Konfirmasi", MessageBoxButtons.YesNo);
                if (confirm == DialogResult.Yes)
                {
                    DeleteMantan(id);
                    LoadData();
                }
            }
        }

        private void DeleteMantan(int id)
        {
            Database db = new Database();
            using (MySqlConnection conn = db.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = "DELETE FROM mantan WHERE id = @id";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Gagal menghapus data: " + ex.Message);
                }
            }
        }
    }
}
