using DaftarMantanApp.Models;
using System.Collections.Generic;

namespace DaftarMantanApp.Controllers
{
    public class MantanController
    {
        private Database db = new Database();

        public List<Mantan> GetAll() => db.GetAllMantan();
        public void TambahMantan(Mantan m) => db.InsertMantan(m);
        public void UpdateMantan(Mantan m) => db.UpdateMantan(m);
        public void HapusMantan(int id) => db.DeleteMantan(id);
    }
}
